<?php
$suma=0;
for ($i=1;$i<=100;$i++) {
    $suma+=($i*$i);
}

echo "La suma es: ".$suma;

?>

